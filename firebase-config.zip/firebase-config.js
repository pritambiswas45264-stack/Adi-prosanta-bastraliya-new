export const firebaseConfig = {
  apiKey: "AIzaSyCRd5jN5elluCuvxDSaOTJEXD0_qC7xsTE",
  authDomain: "adi-prosanta-bastraliya.firebaseapp.com",
  databaseURL: "https://adi-prosanta-bastraliya-default-rtdb.firebaseio.com",
  projectId: "adi-prosanta-bastraliya",
  storageBucket: "adi-prosanta-bastraliya.firebasestorage.app",
  messagingSenderId: "865614263318",
  appId: "1:865614263318:web:956ef8080059d561ccf137",
  measurementId: "G-D3BG50D8GV"
};
